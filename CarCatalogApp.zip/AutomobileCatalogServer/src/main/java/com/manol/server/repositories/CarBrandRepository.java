package com.manol.server.repositories;

import org.springframework.data.repository.CrudRepository;

import com.manol.server.entities.CarBrand;

public interface CarBrandRepository  extends CrudRepository<CarBrand, String> {

}
