package com.manol.server.repositories;

import java.util.List;

import org.springframework.data.domain.Example;
import org.springframework.data.repository.CrudRepository;

import com.manol.server.entities.Car;



public interface CarRepository extends CrudRepository<Car, String> {

	List<Car> findAll(Example<Car> example);

}