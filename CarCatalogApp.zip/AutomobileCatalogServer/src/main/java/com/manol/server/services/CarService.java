package com.manol.server.services;

import java.util.List;
import java.util.Optional;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.manol.server.entities.Car;
import com.manol.server.entities.CarBrand;
import com.manol.server.entities.Model;
import com.manol.server.entities.Owner;
import com.manol.server.repositories.CarBrandRepository;
import com.manol.server.repositories.CarRepository;
import com.manol.server.repositories.ModelRepository;
import com.manol.server.repositories.OwnerRepository;

//Does the conversion operations between the REST API and the Entity layer
@Service
public class CarService {
	@Autowired
	private CarRepository carRepository;
	@Autowired
	private OwnerRepository ownerRepository;
	@Autowired
	private CarBrandRepository carBrandRepository;
	@Autowired
	private ModelRepository modelRepository;

	// finds a Car by registrationID
	public JSONObject searchByID(String registrationID) {

		Optional<Car> opCar = carRepository.findById(registrationID);
		if (opCar.isPresent()) {
			return opCar.get().toJSON();
		} else {
			return null;
		}

	}

	// updates any parameter in a car based on the regID
	public String updateCar(String registrationID, String cubicCentimeters,
			String color, String horsePower, String litersPer100km,
			String owner, String carBrand, String model) {

		Optional<Car> opCar = carRepository.findById(registrationID);
		if (opCar.isEmpty()) {
			return "No such entry";
		}
		Car car = opCar.get();
		if (!cubicCentimeters.isEmpty()) {
			try {
				double cc = Double.parseDouble(cubicCentimeters);
				car.setCubicCentimeters(cc);
			} catch (NumberFormatException e) {

			}
		}

		if (!color.isEmpty()) {
			car.setColor(color);
		}

		if (!horsePower.isEmpty()) {
			try {
				double hp = Double.parseDouble(horsePower);
				car.setHorsePower(hp);
			} catch (NumberFormatException e) {

			}
		}

		if (!litersPer100km.isEmpty()) {
			try {
				double lp100 = Double.parseDouble(litersPer100km);
				car.setHorsePower(lp100);
			} catch (NumberFormatException e) {

			}
		}

		if (!owner.isEmpty()) {
			Optional<Owner> opOwner = ownerRepository.findById(owner);
			if (opOwner.isPresent()) {
				car.setOwner(opOwner.get());
			}
		}

		if (!carBrand.isEmpty()) {
			Optional<CarBrand> opCB = carBrandRepository.findById(carBrand);
			if (opCB.isPresent()) {
				car.setBrand(opCB.get());
			}
		}

		if (!model.isEmpty()) {
			Optional<Model> opModel = modelRepository.findById(model);
			if (opModel.isPresent()) {
				car.setModel(opModel.get());
			}
		}

		return car.getRegistrationID();

	}

	// querries all cars by any attributes given
	public JSONArray searchCars(String registrationID, String cubicCentimeters,
			String color, String horsePower, String litersPer100km,
			String owner, String carBrand, String model) {

		Car car = new Car(registrationID, Double.parseDouble(cubicCentimeters),
				color, Double.parseDouble(horsePower),
				Double.parseDouble(litersPer100km),
				ownerRepository.findById("owner").get(),
				carBrandRepository.findById(carBrand).get(),
				modelRepository.findById(model).get());

		Example<Car> example = Example.of(car);

		example.getMatcher().getMatchMode().valueOf("ALL");

		List<Car> cars = carRepository.findAll(example);

		JSONArray jsonArr = new JSONArray(cars);

		return jsonArr;
	}

	// deletes all cars matching all attributes
	public void deleteCars(String registrationID, String cubicCentimeters,
			String color, String horsePower, String litersPer100km,
			String owner, String carBrand, String model) {

		Car car = new Car(registrationID, Double.parseDouble(cubicCentimeters),
				color, Double.parseDouble(horsePower),
				Double.parseDouble(litersPer100km),
				ownerRepository.findById("owner").get(),
				carBrandRepository.findById(carBrand).get(),
				modelRepository.findById(model).get());

		Example<Car> example = Example.of(car);

		example.getMatcher().getMatchMode().valueOf("ALL");

		List<Car> cars = carRepository.findAll(example);
		carRepository.deleteAll(cars);

	}

	// creates a new car and if the owner, bran or model is new it creates that
	// as well
	public String saveCar(JSONObject json) {
		// we create new entries for ones not in the DB already
		Owner owner;
		String owName = json.getString("owner");
		Optional<Owner> opOw = ownerRepository.findById(owName);
		if (opOw.isPresent()) {
			owner = opOw.get();
		} else {
			owner = saveOwner(owName);
		}

		CarBrand carBrand;
		String cbName = json.getString("carBrand");
		Optional<CarBrand> opCb = carBrandRepository.findById(cbName);
		if (opCb.isPresent()) {
			carBrand = opCb.get();
		} else {
			carBrand = saveCarBrand(cbName);
		}

		Model model;
		String modelName = json.getString("model");
		Optional<Model> opModel = modelRepository.findById(modelName);
		if (opModel.isPresent()) {
			model = opModel.get();
		} else {
			model = saveModel(modelName);
		}

		String reg = json.getString("registrationID");
		double cc = json.getNumber("cubicCentimeters").doubleValue();
		String color = json.getString("color");
		double hp = json.getNumber("horsePower").doubleValue();
		double lp100 = json.getNumber("litersPer100km").doubleValue();

		Car car = new Car(reg, cc, color, hp, lp100, owner, carBrand, model);

		carRepository.save(car);

		return car.getRegistrationID();
	}

	private Owner saveOwner(String name) {
		Owner owner = new Owner(name);
		ownerRepository.save(owner);
		return owner;

	}

	private CarBrand saveCarBrand(String name) {
		CarBrand carBrand = new CarBrand(name);
		carBrandRepository.save(carBrand);
		return carBrand;

	}

	private Model saveModel(String name) {
		Model model = new Model(name);
		modelRepository.save(model);
		return model;

	}
}
