package com.manol.server.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.json.JSONObject;
import org.springframework.data.jpa.repository.JpaRepository;

@Entity
@Table
public class Car {

	    @Id
	    @Column
	    private String registrationID;
	    
	    @Column
	    private double cubicCentimeters;
	    @Column
	    private String color;
	    @Column
	    private double horsePower;
	    @Column
	    private double litersPer100km;
	    
	    @ManyToOne
	    @JoinColumn
	    private Owner owner;
	    
	    @ManyToOne
	    @JoinColumn
	    private CarBrand brand;
	    
	    @ManyToOne
	    @JoinColumn
	    private Model model;
	    
	    protected Car() {}

		public Car(String registrationID, double cubicCentimeters, String color,
				double horsePower, double litersPer100km, Owner owner,
				CarBrand brand, Model model) {
			this.registrationID = registrationID;
			this.cubicCentimeters = cubicCentimeters;
			this.color = color;
			this.horsePower = horsePower;
			this.litersPer100km = litersPer100km;
			this.owner = owner;
			this.brand = brand;
			this.model = model;
		}

		public String getRegistrationID() {
			return registrationID;
		}

		public void setRegistrationID(String registrationID) {
			this.registrationID = registrationID;
		}

		public double getCubicCentimeters() {
			return cubicCentimeters;
		}

		public void setCubicCentimeters(double cubicCentimeters) {
			this.cubicCentimeters = cubicCentimeters;
		}

		public String getColor() {
			return color;
		}

		public void setColor(String color) {
			this.color = color;
		}

		public double getHorsePower() {
			return horsePower;
		}

		public void setHorsePower(double horsePower) {
			this.horsePower = horsePower;
		}

		public double getLitersPer100km() {
			return litersPer100km;
		}

		public void setLitersPer100km(double litersPer100km) {
			this.litersPer100km = litersPer100km;
		}

		public Owner getOwner() {
			return owner;
		}

		public void setOwner(Owner owner) {
			this.owner = owner;
		}

		public CarBrand getBrand() {
			return brand;
		}

		public void setBrand(CarBrand brand) {
			this.brand = brand;
		}

		public Model getModel() {
			return model;
		}

		public void setModel(Model model) {
			this.model = model;
		};
		
		public JSONObject toJSON() {
			JSONObject carJSON = new JSONObject();
			carJSON.put("registrationID", registrationID);
			carJSON.put("cubicCentimeters", cubicCentimeters);
			carJSON.put("color", color);
			carJSON.put("horsePower", horsePower);
			carJSON.put("litersPer100km", litersPer100km);
			carJSON.put("owner", owner.getName());
			carJSON.put("carBrand", brand.getName());
			carJSON.put("model", model.getName());
			
			return carJSON;
		}
		
	
	    
	    
	    
	    
}


