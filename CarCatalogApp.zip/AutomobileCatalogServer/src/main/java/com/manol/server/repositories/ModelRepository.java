package com.manol.server.repositories;

import org.springframework.data.repository.CrudRepository;

import com.manol.server.entities.Model;

public interface ModelRepository extends CrudRepository<Model, String> {

}