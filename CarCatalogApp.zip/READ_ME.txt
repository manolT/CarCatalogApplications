Requirements:
I am sending 2 eclipse Projects
The server runs from com.manol.server.AutomobileCatalogServerApplication.java
My applications are using Java 11.
It uses port 8080 on http://localhost/.

Implementation of Server:
The applications was implemented using Maven and Spring Boot(JPA, H2, Web)

I used JPA and H2 for an integrated SQL database.
There is an Entity layer and a Repository layer.
The Srver is currently set up to keep the database in memory while running.

Above that is the business layer where the services are. 
Currently there is only one- CarService. It deals with 
organising the CRUD operations.
I opted to use querry parameters (On the Controller layer) for search and 
delete where all cars that match all fields are returned/ deleted. Also 
when a new Car is created

Above that there is the RestController, that simply manages the REST
communication, which offloads all the work to the Service layer.

Client:
Unfortunetly I didn't have the time to properly set up the ClientApp, but I tested most components manually.








