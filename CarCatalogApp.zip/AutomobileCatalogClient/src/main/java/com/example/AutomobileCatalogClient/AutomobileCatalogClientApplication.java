package com.example.AutomobileCatalogClient;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class AutomobileCatalogClientApplication {

	private static final Logger log = LoggerFactory
			.getLogger(AutomobileCatalogClientApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(AutomobileCatalogClientApplication.class, args);
	}

	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}

	@Bean
	public CommandLineRunner run(RestTemplate restTemplate) throws Exception {
		JSONObject cj = new JSONObject();
		cj.put("registrationID", "reg1");
		cj.put("cubicCentimeters", "2.5");
		cj.put("color", "blue");
		cj.put("horsePower", "90");
		cj.put("litersPer100km", "6.2");
		cj.put("owner", "Bobby Fischer");
		cj.put("carBrand", "Skoda");
		cj.put("model", "Octavia");
		return args -> {
			Quote quote = restTemplate.postForObject("http://localhost:8080/create/car/",
					cj, Quote.class);
			log.info(quote.toString());
		};
	}
}
