package com.example.AutomobileCatalogClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutomobileCatalogClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
